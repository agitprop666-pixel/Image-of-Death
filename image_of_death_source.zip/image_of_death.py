from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, QRect, QPoint, QSize, pyqtSignal
from PyQt6.QtGui import (
    QPixmap, QImage, QPainter, QPen, QColor, QCursor, 
    QAction, QIcon, QFont, QPalette
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFileDialog, QMessageBox, QScrollArea,
    QDialog, QSpinBox, QDoubleSpinBox, QComboBox, QFormLayout,
    QDialogButtonBox, QGroupBox, QStatusBar, QMenuBar, QMenu,
    QToolBar, QSizePolicy, QSplashScreen
)

from PIL import Image
from PIL.PngImagePlugin import PngInfo

# =============================================================================
# Constants
# =============================================================================
APP_NAME = "Image of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"

SUPPORTED_FORMATS = {
    'JPEG': ['.jpg', '.jpeg'],
    'PNG': ['.png'],
    'GIF': ['.gif'],
    'BMP': ['.bmp'],
    'TIFF': ['.tiff', '.tif'],
    'ICO': ['.ico'],
    'ICNS': ['.icns'],
    'WEBP': ['.webp']
}

# =============================================================================
# Splash Screen Function
# =============================================================================
def create_splash():
    """
    Creates the QSplashScreen.

    It first checks for an external 'splash.png'. If not found, it generates
    a dark screen with the app name, org name, and ASCII skull art.
    """
    try:
        # Check for splash.png in the same directory as the script
        splash_path = Path(__file__).parent / "splash.png"
        
        if splash_path.exists():
            # Load the splash.png file
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate the dark-themed screen with ASCII art skull
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Crop Widget
# =============================================================================
class CropWidget(QWidget):
    """Interactive crop widget with draggable handles on all 4 sides"""
    
    cropChanged = pyqtSignal(QRect)
    
    def __init__(self, pixmap: QPixmap, parent=None):
        super().__init__(parent)
        self.original_pixmap = pixmap
        self.display_pixmap = pixmap  # Scaled version for display
        self.scale_factor = 1.0
        
        # Crop rectangle in ORIGINAL image coordinates
        self.crop_rect = QRect(0, 0, pixmap.width(), pixmap.height())
        
        # Handle size
        self.handle_size = 10
        
        # Dragging state
        self.dragging = None  # 'left', 'right', 'top', 'bottom', 'tl', 'tr', 'bl', 'br', 'move'
        self.drag_start_pos = None
        self.drag_start_rect = None
        
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
    def resizeEvent(self, event):
        """Scale image to fit widget when resized"""
        super().resizeEvent(event)
        self.scale_image_to_fit()
        
    def scale_image_to_fit(self):
        """Scale the image to fit the current widget size"""
        if self.original_pixmap.isNull():
            return
            
        available_size = self.size()
        
        # Scale pixmap to fit widget while maintaining aspect ratio
        self.display_pixmap = self.original_pixmap.scaled(
            available_size,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        
        # Calculate scale factor
        self.scale_factor = self.display_pixmap.width() / self.original_pixmap.width()
        
        self.setMinimumSize(self.display_pixmap.size())
        self.update()
        
    def get_display_rect(self):
        """Convert original crop rect to display coordinates"""
        return QRect(
            int(self.crop_rect.x() * self.scale_factor),
            int(self.crop_rect.y() * self.scale_factor),
            int(self.crop_rect.width() * self.scale_factor),
            int(self.crop_rect.height() * self.scale_factor)
        )
        
    def set_crop_from_display(self, display_rect):
        """Convert display coordinates back to original coordinates"""
        self.crop_rect = QRect(
            int(display_rect.x() / self.scale_factor),
            int(display_rect.y() / self.scale_factor),
            int(display_rect.width() / self.scale_factor),
            int(display_rect.height() / self.scale_factor)
        )
        
    def sizeHint(self):
        """Provide size hint for proper layout"""
        return self.display_pixmap.size()
        
    def paintEvent(self, event):
        painter = QPainter(self)
        
        # Draw the scaled image centered
        x_offset = (self.width() - self.display_pixmap.width()) // 2
        y_offset = (self.height() - self.display_pixmap.height()) // 2
        painter.drawPixmap(x_offset, y_offset, self.display_pixmap)
        
        # Get display coordinates for crop rect
        display_crop = self.get_display_rect()
        display_crop.translate(x_offset, y_offset)
        
        # Draw semi-transparent overlay outside crop area
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 150))
        
        # Top overlay
        if display_crop.top() > y_offset:
            painter.drawRect(x_offset, y_offset, self.display_pixmap.width(), 
                           display_crop.top() - y_offset)
        
        # Bottom overlay
        if display_crop.bottom() < y_offset + self.display_pixmap.height():
            painter.drawRect(x_offset, display_crop.bottom(), 
                           self.display_pixmap.width(),
                           y_offset + self.display_pixmap.height() - display_crop.bottom())
        
        # Left overlay
        painter.drawRect(x_offset, display_crop.top(), 
                        display_crop.left() - x_offset, display_crop.height())
        
        # Right overlay
        painter.drawRect(display_crop.right(), display_crop.top(),
                        x_offset + self.display_pixmap.width() - display_crop.right(), 
                        display_crop.height())
        
        # Draw crop rectangle border
        painter.setPen(QPen(QColor(255, 255, 0), 2, Qt.PenStyle.DashLine))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(display_crop)
        
        # Draw handles
        painter.setPen(QPen(QColor(255, 255, 0), 2))
        painter.setBrush(QColor(255, 255, 255))
        
        # Corner handles
        self._draw_handle(painter, display_crop.topLeft())
        self._draw_handle(painter, display_crop.topRight())
        self._draw_handle(painter, display_crop.bottomLeft())
        self._draw_handle(painter, display_crop.bottomRight())
        
        # Edge handles
        self._draw_handle(painter, QPoint(display_crop.center().x(), display_crop.top()))
        self._draw_handle(painter, QPoint(display_crop.center().x(), display_crop.bottom()))
        self._draw_handle(painter, QPoint(display_crop.left(), display_crop.center().y()))
        self._draw_handle(painter, QPoint(display_crop.right(), display_crop.center().y()))
        
    def _draw_handle(self, painter, center):
        """Draw a handle at the given center point"""
        rect = QRect(center.x() - self.handle_size // 2,
                    center.y() - self.handle_size // 2,
                    self.handle_size, self.handle_size)
        painter.drawRect(rect)
        
    def _get_handle_at_pos(self, pos):
        """Determine which handle (if any) is at the given position"""
        x_offset = (self.width() - self.display_pixmap.width()) // 2
        y_offset = (self.height() - self.display_pixmap.height()) // 2
        display_crop = self.get_display_rect()
        display_crop.translate(x_offset, y_offset)
        
        hs = self.handle_size
        
        # Check corner handles
        if self._point_near(pos, display_crop.topLeft(), hs):
            return 'tl'
        if self._point_near(pos, display_crop.topRight(), hs):
            return 'tr'
        if self._point_near(pos, display_crop.bottomLeft(), hs):
            return 'bl'
        if self._point_near(pos, display_crop.bottomRight(), hs):
            return 'br'
            
        # Check edge handles
        if self._point_near(pos, QPoint(display_crop.center().x(), display_crop.top()), hs):
            return 'top'
        if self._point_near(pos, QPoint(display_crop.center().x(), display_crop.bottom()), hs):
            return 'bottom'
        if self._point_near(pos, QPoint(display_crop.left(), display_crop.center().y()), hs):
            return 'left'
        if self._point_near(pos, QPoint(display_crop.right(), display_crop.center().y()), hs):
            return 'right'
            
        # Check if inside crop rect (for moving)
        if display_crop.contains(pos):
            return 'move'
            
        return None
        
    def _point_near(self, p1, p2, threshold):
        """Check if two points are within threshold distance"""
        dx = p1.x() - p2.x()
        dy = p1.y() - p2.y()
        return (dx * dx + dy * dy) <= (threshold * threshold)
        
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = self._get_handle_at_pos(event.pos())
            self.drag_start_pos = event.pos()
            
            # Store in display coordinates
            x_offset = (self.width() - self.display_pixmap.width()) // 2
            y_offset = (self.height() - self.display_pixmap.height()) // 2
            display_crop = self.get_display_rect()
            display_crop.translate(x_offset, y_offset)
            self.drag_start_rect = QRect(display_crop)
            
    def mouseMoveEvent(self, event):
        if self.dragging:
            x_offset = (self.width() - self.display_pixmap.width()) // 2
            y_offset = (self.height() - self.display_pixmap.height()) // 2
            
            dx = event.pos().x() - self.drag_start_pos.x()
            dy = event.pos().y() - self.drag_start_pos.y()
            
            new_rect = QRect(self.drag_start_rect)
            
            if self.dragging == 'left' or self.dragging in ['tl', 'bl']:
                new_rect.setLeft(min(self.drag_start_rect.left() + dx, 
                                   self.drag_start_rect.right() - 10))
            if self.dragging == 'right' or self.dragging in ['tr', 'br']:
                new_rect.setRight(max(self.drag_start_rect.right() + dx,
                                    self.drag_start_rect.left() + 10))
            if self.dragging == 'top' or self.dragging in ['tl', 'tr']:
                new_rect.setTop(min(self.drag_start_rect.top() + dy,
                                  self.drag_start_rect.bottom() - 10))
            if self.dragging == 'bottom' or self.dragging in ['bl', 'br']:
                new_rect.setBottom(max(self.drag_start_rect.bottom() + dy,
                                     self.drag_start_rect.top() + 10))
            if self.dragging == 'move':
                new_rect.translate(dx, dy)
                # Keep within bounds
                if new_rect.left() < x_offset:
                    new_rect.moveLeft(x_offset)
                if new_rect.right() > x_offset + self.display_pixmap.width():
                    new_rect.moveRight(x_offset + self.display_pixmap.width())
                if new_rect.top() < y_offset:
                    new_rect.moveTop(y_offset)
                if new_rect.bottom() > y_offset + self.display_pixmap.height():
                    new_rect.moveBottom(y_offset + self.display_pixmap.height())
            
            # Constrain to image bounds
            image_bounds = QRect(x_offset, y_offset, 
                               self.display_pixmap.width(), 
                               self.display_pixmap.height())
            new_rect = new_rect.intersected(image_bounds)
            
            # Translate back to image space
            new_rect.translate(-x_offset, -y_offset)
            self.set_crop_from_display(new_rect)
            
            self.update()
            self.cropChanged.emit(self.crop_rect)
        else:
            # Update cursor based on position
            handle = self._get_handle_at_pos(event.pos())
            if handle in ['tl', 'br']:
                self.setCursor(QCursor(Qt.CursorShape.SizeFDiagCursor))
            elif handle in ['tr', 'bl']:
                self.setCursor(QCursor(Qt.CursorShape.SizeBDiagCursor))
            elif handle in ['left', 'right']:
                self.setCursor(QCursor(Qt.CursorShape.SizeHorCursor))
            elif handle in ['top', 'bottom']:
                self.setCursor(QCursor(Qt.CursorShape.SizeVerCursor))
            elif handle == 'move':
                self.setCursor(QCursor(Qt.CursorShape.SizeAllCursor))
            else:
                self.setCursor(QCursor(Qt.CursorShape.ArrowCursor))
                
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.dragging = None
            self.drag_start_pos = None
            self.drag_start_rect = None

# =============================================================================
# Crop Dialog
# =============================================================================
class CropDialog(QDialog):
    """Dialog for cropping an image"""
    
    def __init__(self, pixmap: QPixmap, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Crop Image")
        # Make resizable and set initial size
        self.setMinimumSize(600, 400)
        self.resize(1200, 800)
        
        layout = QVBoxLayout(self)
        
        # Info label
        info_label = QLabel("Drag the handles to adjust the crop area")
        layout.addWidget(info_label)
        
        # Scroll area for large images
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        
        # Crop widget
        self.crop_widget = CropWidget(pixmap)
        self.crop_widget.cropChanged.connect(self.on_crop_changed)
        scroll.setWidget(self.crop_widget)
        layout.addWidget(scroll)
        
        # Info about current crop
        self.crop_info = QLabel()
        self.update_crop_info(self.crop_widget.crop_rect)
        layout.addWidget(self.crop_info)
        
        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.apply_dark_theme()
        
    def showEvent(self, event):
        """Maximize window when shown"""
        super().showEvent(event)
        self.showMaximized()
        
    def on_crop_changed(self, rect):
        self.update_crop_info(rect)
        
    def update_crop_info(self, rect):
        self.crop_info.setText(
            f"Crop Area: {rect.width()} x {rect.height()} pixels "
            f"(X: {rect.x()}, Y: {rect.y()}) - Original Image Coordinates"
        )
        
    def get_crop_rect(self):
        return self.crop_widget.crop_rect
        
    def apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
        """)

# =============================================================================
# Resize Dialog
# =============================================================================
class ResizeDialog(QDialog):
    """Dialog for resizing an image"""
    
    def __init__(self, current_width: int, current_height: int, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Resize Image")
        self.setMinimumSize(350, 200)  # Make resizable
        
        self.current_width = current_width
        self.current_height = current_height
        self.aspect_ratio = current_width / current_height
        self.lock_aspect = True
        
        layout = QFormLayout(self)
        
        # Width
        self.width_spin = QSpinBox()
        self.width_spin.setRange(1, 10000)
        self.width_spin.setValue(current_width)
        self.width_spin.valueChanged.connect(self.on_width_changed)
        layout.addRow("Width (px):", self.width_spin)
        
        # Height
        self.height_spin = QSpinBox()
        self.height_spin.setRange(1, 10000)
        self.height_spin.setValue(current_height)
        self.height_spin.valueChanged.connect(self.on_height_changed)
        layout.addRow("Height (px):", self.height_spin)
        
        # Lock aspect ratio checkbox
        self.lock_check = QPushButton("🔒 Aspect Ratio: Locked")
        self.lock_check.setCheckable(True)
        self.lock_check.setChecked(True)
        self.lock_check.clicked.connect(self.toggle_lock)
        layout.addRow("", self.lock_check)
        
        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addRow(button_box)
        
        self.apply_dark_theme()
        
    def toggle_lock(self):
        self.lock_aspect = self.lock_check.isChecked()
        if self.lock_aspect:
            self.lock_check.setText("🔒 Aspect Ratio: Locked")
            self.aspect_ratio = self.width_spin.value() / self.height_spin.value()
        else:
            self.lock_check.setText("🔓 Aspect Ratio: Unlocked")
            
    def on_width_changed(self, value):
        if self.lock_aspect and self.height_spin.value() != int(value / self.aspect_ratio):
            self.height_spin.blockSignals(True)
            self.height_spin.setValue(int(value / self.aspect_ratio))
            self.height_spin.blockSignals(False)
            
    def on_height_changed(self, value):
        if self.lock_aspect and self.width_spin.value() != int(value * self.aspect_ratio):
            self.width_spin.blockSignals(True)
            self.width_spin.setValue(int(value * self.aspect_ratio))
            self.width_spin.blockSignals(False)
            
    def get_size(self):
        return (self.width_spin.value(), self.height_spin.value())
        
    def apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
            QSpinBox {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 3px;
            }
            QPushButton {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
        """)

# =============================================================================
# DPI Dialog
# =============================================================================
class DPIDialog(QDialog):
    """Dialog for changing DPI"""
    
    def __init__(self, current_dpi: tuple = (72, 72), image_size: tuple = (1, 1), parent=None):
        super().__init__(parent)
        self.setWindowTitle("Change DPI")
        self.setMinimumSize(450, 300)  # Make resizable
        
        self.current_dpi = current_dpi
        self.image_width = image_size[0]
        self.image_height = image_size[1]
        
        layout = QVBoxLayout(self)
        
        # Info about current image
        info_label = QLabel(f"Current: {self.image_width}×{self.image_height} pixels at {int(round(current_dpi[0]))}×{int(round(current_dpi[1]))} DPI")
        info_label.setStyleSheet("color: #aaaaaa; padding: 5px;")
        layout.addWidget(info_label)
        
        form_layout = QFormLayout()
        
        # DPI X
        self.dpi_x_spin = QSpinBox()
        self.dpi_x_spin.setRange(1, 5000)
        dpi_x_value = int(round(current_dpi[0])) if current_dpi and current_dpi[0] else 72
        self.dpi_x_spin.setValue(dpi_x_value)
        self.dpi_x_spin.valueChanged.connect(self.update_preview)
        form_layout.addRow("DPI X:", self.dpi_x_spin)
        
        # DPI Y
        self.dpi_y_spin = QSpinBox()
        self.dpi_y_spin.setRange(1, 5000)
        dpi_y_value = int(round(current_dpi[1])) if current_dpi and current_dpi[1] else 72
        self.dpi_y_spin.setValue(dpi_y_value)
        self.dpi_y_spin.valueChanged.connect(self.update_preview)
        form_layout.addRow("DPI Y:", self.dpi_y_spin)
        
        layout.addLayout(form_layout)
        
        # Common presets
        preset_layout = QHBoxLayout()
        preset_label = QLabel("Presets:")
        preset_label.setStyleSheet("color: #aaaaaa;")
        preset_layout.addWidget(preset_label)
        for dpi in [72, 96, 150, 300, 600]:
            btn = QPushButton(str(dpi))
            btn.clicked.connect(lambda checked, d=dpi: self.set_preset(d))
            preset_layout.addWidget(btn)
        layout.addLayout(preset_layout)
        
        layout.addSpacing(10)
        
        # Resample checkbox
        self.resample_check = QPushButton("☐ Resample Image (change pixel dimensions)")
        self.resample_check.setCheckable(True)
        self.resample_check.setChecked(False)
        self.resample_check.clicked.connect(self.toggle_resample)
        self.resample_check.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 8px;
                background-color: #3c3c3c;
                border: 1px solid #555555;
            }
            QPushButton:checked {
                background-color: #4a4a4a;
            }
        """)
        layout.addWidget(self.resample_check)
        
        # Preview of what will happen
        self.preview_label = QLabel()
        self.preview_label.setWordWrap(True)
        self.preview_label.setStyleSheet("color: #ffdd00; padding: 10px; background-color: #3c3c3c; border-radius: 3px;")
        layout.addWidget(self.preview_label)
        
        self.update_preview()
        
        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.apply_dark_theme()
        
    def toggle_resample(self):
        if self.resample_check.isChecked():
            self.resample_check.setText("☑ Resample Image (change pixel dimensions)")
        else:
            self.resample_check.setText("☐ Resample Image (change pixel dimensions)")
        self.update_preview()
        
    def update_preview(self):
        """Update the preview text showing what will happen"""
        new_dpi_x = self.dpi_x_spin.value()
        new_dpi_y = self.dpi_y_spin.value()
        
        if self.resample_check.isChecked():
            # Calculate new dimensions maintaining physical size
            # Physical size = pixels / DPI
            # New pixels = physical size × new DPI
            new_width = int(round((self.image_width / self.current_dpi[0]) * new_dpi_x))
            new_height = int(round((self.image_height / self.current_dpi[1]) * new_dpi_y))
            
            physical_width = self.image_width / self.current_dpi[0]
            physical_height = self.image_height / self.current_dpi[1]
            
            self.preview_label.setText(
                f"<b>With Resampling:</b><br>"
                f"New dimensions: {new_width}×{new_height} pixels<br>"
                f"Physical print size: {physical_width:.2f}×{physical_height:.2f} inches (unchanged)<br>"
                f"DPI: {new_dpi_x}×{new_dpi_y}<br>"
                f"<i>Note: Pixel count will change, similar to Photoshop's 'Resample'</i>"
            )
        else:
            # Just changing metadata
            physical_width = self.image_width / new_dpi_x
            physical_height = self.image_height / new_dpi_y
            
            self.preview_label.setText(
                f"<b>Without Resampling:</b><br>"
                f"Dimensions: {self.image_width}×{self.image_height} pixels (unchanged)<br>"
                f"Physical print size: {physical_width:.2f}×{physical_height:.2f} inches<br>"
                f"DPI: {new_dpi_x}×{new_dpi_y}<br>"
                f"<i>Note: Only metadata changes, pixels stay the same</i>"
            )
        
    def set_preset(self, dpi):
        self.dpi_x_spin.setValue(dpi)
        self.dpi_y_spin.setValue(dpi)
        
    def get_dpi(self):
        return (self.dpi_x_spin.value(), self.dpi_y_spin.value())
        
    def should_resample(self):
        return self.resample_check.isChecked()
        
    def get_new_dimensions(self):
        """Calculate new dimensions if resampling"""
        if not self.should_resample():
            return (self.image_width, self.image_height)
        
        new_dpi_x = self.dpi_x_spin.value()
        new_dpi_y = self.dpi_y_spin.value()
        
        new_width = int(round((self.image_width / self.current_dpi[0]) * new_dpi_x))
        new_height = int(round((self.image_height / self.current_dpi[1]) * new_dpi_y))
        
        return (new_width, new_height)
        
    def apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
            QSpinBox {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 3px;
            }
            QPushButton {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 5px;
                min-width: 50px;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
        """)

# =============================================================================
# Image Info Dialog
# =============================================================================
class ImageInfoDialog(QDialog):
    """Dialog for displaying image information"""
    
    def __init__(self, image: Image.Image, file_path: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Image Information")
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Image Details")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #ffffff;")
        layout.addWidget(title)
        
        layout.addSpacing(10)
        
        # Info grid
        info_layout = QFormLayout()
        info_layout.setSpacing(8)
        
        # File information
        info_layout.addRow(self._create_label("Filename:"), 
                          self._create_value(file_path.name))
        
        info_layout.addRow(self._create_label("Location:"), 
                          self._create_value(str(file_path.parent)))
        
        # File size
        file_size = file_path.stat().st_size
        if file_size < 1024:
            size_str = f"{file_size} bytes"
        elif file_size < 1024 * 1024:
            size_str = f"{file_size / 1024:.2f} KB"
        else:
            size_str = f"{file_size / (1024 * 1024):.2f} MB"
        info_layout.addRow(self._create_label("File Size:"), 
                          self._create_value(size_str))
        
        # Image dimensions
        info_layout.addRow(self._create_label("Dimensions:"), 
                          self._create_value(f"{image.width} × {image.height} pixels"))
        
        # Aspect ratio
        from math import gcd
        g = gcd(image.width, image.height)
        aspect = f"{image.width // g}:{image.height // g}"
        info_layout.addRow(self._create_label("Aspect Ratio:"), 
                          self._create_value(aspect))
        
        # Format
        format_name = image.format or "Unknown"
        info_layout.addRow(self._create_label("Format:"), 
                          self._create_value(format_name))
        
        # Color mode
        mode_descriptions = {
            '1': '1-bit pixels, black and white',
            'L': 'Grayscale (8-bit)',
            'P': 'Palette mode (8-bit)',
            'RGB': 'True Color (24-bit)',
            'RGBA': 'True Color with Alpha (32-bit)',
            'CMYK': 'CMYK (32-bit)',
            'YCbCr': 'YCbCr (24-bit)',
            'LAB': 'LAB (24-bit)',
            'HSV': 'HSV (24-bit)',
            'I': 'Integer pixels (32-bit)',
            'F': 'Floating point pixels (32-bit)'
        }
        mode_desc = mode_descriptions.get(image.mode, image.mode)
        info_layout.addRow(self._create_label("Color Mode:"), 
                          self._create_value(mode_desc))
        
        # DPI
        dpi = image.info.get('dpi', (72, 72))
        if isinstance(dpi, tuple):
            # Handle float DPI values from Pillow
            dpi_str = f"{int(round(dpi[0]))} × {int(round(dpi[1]))}"
        else:
            dpi_str = str(int(round(dpi))) if isinstance(dpi, (int, float)) else str(dpi)
        info_layout.addRow(self._create_label("DPI:"), 
                          self._create_value(dpi_str))
        
        # Total pixels
        total_pixels = image.width * image.height
        if total_pixels >= 1_000_000:
            megapixels = total_pixels / 1_000_000
            info_layout.addRow(self._create_label("Total Pixels:"), 
                              self._create_value(f"{megapixels:.2f} Megapixels"))
        else:
            info_layout.addRow(self._create_label("Total Pixels:"), 
                              self._create_value(f"{total_pixels:,}"))
        
        # Additional format-specific info
        if image.format == 'JPEG' and 'quality' in image.info:
            info_layout.addRow(self._create_label("JPEG Quality:"), 
                              self._create_value(str(image.info['quality'])))
        
        if 'compression' in image.info:
            info_layout.addRow(self._create_label("Compression:"), 
                              self._create_value(str(image.info['compression'])))
        
        layout.addLayout(info_layout)
        layout.addSpacing(10)
        
        # Close button
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
        button_box.accepted.connect(self.accept)
        layout.addWidget(button_box)
        
        self.apply_dark_theme()
        
    def _create_label(self, text):
        """Create a label for the info key"""
        label = QLabel(text)
        label.setStyleSheet("color: #aaaaaa; font-weight: bold;")
        return label
        
    def _create_value(self, text):
        """Create a label for the info value"""
        label = QLabel(text)
        label.setStyleSheet("color: #ffffff;")
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return label
        
    def apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
        """)

# =============================================================================
# Convert Dialog
# =============================================================================
class ConvertDialog(QDialog):
    """Dialog for converting image format"""
    
    def __init__(self, current_format: str = 'PNG', parent=None):
        super().__init__(parent)
        self.setWindowTitle("Convert Image Format")
        self.setMinimumSize(350, 200)  # Make resizable
        
        layout = QFormLayout(self)
        
        # Format selector
        self.format_combo = QComboBox()
        for fmt in SUPPORTED_FORMATS.keys():
            self.format_combo.addItem(fmt)
        
        # Set current format if available
        if current_format.upper() in SUPPORTED_FORMATS:
            self.format_combo.setCurrentText(current_format.upper())
        
        layout.addRow("Convert to:", self.format_combo)
        
        # Quality slider (for JPEG/WEBP)
        self.quality_group = QGroupBox("Quality Settings")
        quality_layout = QFormLayout()
        self.quality_spin = QSpinBox()
        self.quality_spin.setRange(1, 100)
        self.quality_spin.setValue(95)
        quality_layout.addRow("Quality (1-100):", self.quality_spin)
        self.quality_group.setLayout(quality_layout)
        layout.addRow(self.quality_group)
        
        # Update quality visibility
        self.format_combo.currentTextChanged.connect(self.update_quality_visibility)
        self.update_quality_visibility(self.format_combo.currentText())
        
        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addRow(button_box)
        
        self.apply_dark_theme()
        
    def update_quality_visibility(self, format_name):
        # Show quality only for JPEG and WEBP
        self.quality_group.setVisible(format_name in ['JPEG', 'WEBP'])
        
    def get_format(self):
        return self.format_combo.currentText()
        
    def get_quality(self):
        return self.quality_spin.value()
        
    def apply_dark_theme(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QLabel, QGroupBox {
                color: #ffffff;
            }
            QComboBox, QSpinBox {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 3px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #ffffff;
            }
        """)

# =============================================================================
# Main Window
# =============================================================================
class ImageOfDeath(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        
        self.current_image: Optional[Image.Image] = None
        self.current_file_path: Optional[Path] = None
        self.current_pixmap: Optional[QPixmap] = None
        self.last_directory: Path = Path.home()  # Remember last used directory
        
        # Undo/Redo stacks
        self.undo_stack = []
        self.redo_stack = []
        self.max_history = 20  # Maximum number of undo steps
        
        # Track if image has unsaved changes
        self.has_unsaved_changes = False
        
        # Track if image has been modified
        self.is_modified = False
        
        self.init_ui()
        self.apply_dark_theme()
        
    def init_ui(self):
        self.setWindowTitle(f"{APP_NAME} - {ORG_NAME}")
        self.setGeometry(100, 100, 1024, 768)
        self.setMinimumSize(800, 600)  # Set minimum size but allow resizing
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create toolbar
        self.create_toolbar()
        
        # Image display area
        self.scroll_area = QScrollArea()
        self.scroll_area.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll_area.setWidgetResizable(True)
        
        self.image_label = QLabel("No image loaded")
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("QLabel { color: #888888; font-size: 16px; }")
        
        self.scroll_area.setWidget(self.image_label)
        layout.addWidget(self.scroll_area)
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        
    def create_menu_bar(self):
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        open_action = QAction("Open...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_image)
        file_menu.addAction(open_action)
        
        save_action = QAction("Save", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_image)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("Save As...", self)
        save_as_action.setShortcut("Ctrl+Shift+S")
        save_as_action.triggered.connect(self.save_image_as)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        close_action = QAction("Close Image", self)
        close_action.setShortcut("Ctrl+W")
        close_action.triggered.connect(self.close_image)
        file_menu.addAction(close_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("Edit")
        
        undo_action = QAction("Undo", self)
        undo_action.setShortcut("Ctrl+Z")
        undo_action.triggered.connect(self.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Redo", self)
        redo_action.setShortcut("Ctrl+Y")
        redo_action.triggered.connect(self.redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        rotate_menu = edit_menu.addMenu("Rotate")
        
        rotate_90cw_action = QAction("Rotate 90° Clockwise", self)
        rotate_90cw_action.setShortcut("Ctrl+R")
        rotate_90cw_action.triggered.connect(lambda: self.rotate_image(90))
        rotate_menu.addAction(rotate_90cw_action)
        
        rotate_90ccw_action = QAction("Rotate 90° Counter-Clockwise", self)
        rotate_90ccw_action.setShortcut("Ctrl+Shift+R")
        rotate_90ccw_action.triggered.connect(lambda: self.rotate_image(-90))
        rotate_menu.addAction(rotate_90ccw_action)
        
        rotate_180_action = QAction("Rotate 180°", self)
        rotate_180_action.triggered.connect(lambda: self.rotate_image(180))
        rotate_menu.addAction(rotate_180_action)
        
        flip_menu = edit_menu.addMenu("Flip")
        
        flip_h_action = QAction("Flip Horizontal", self)
        flip_h_action.setShortcut("Ctrl+H")
        flip_h_action.triggered.connect(lambda: self.flip_image('horizontal'))
        flip_menu.addAction(flip_h_action)
        
        flip_v_action = QAction("Flip Vertical", self)
        flip_v_action.setShortcut("Ctrl+Shift+H")
        flip_v_action.triggered.connect(lambda: self.flip_image('vertical'))
        flip_menu.addAction(flip_v_action)
        
        edit_menu.addSeparator()
        
        resize_action = QAction("Resize...", self)
        resize_action.triggered.connect(self.resize_image)
        edit_menu.addAction(resize_action)
        
        crop_action = QAction("Crop...", self)
        crop_action.triggered.connect(self.crop_image)
        edit_menu.addAction(crop_action)
        
        edit_menu.addSeparator()
        
        dpi_action = QAction("Change DPI...", self)
        dpi_action.triggered.connect(self.change_dpi)
        edit_menu.addAction(dpi_action)
        
        convert_action = QAction("Convert Format...", self)
        convert_action.triggered.connect(self.convert_format)
        edit_menu.addAction(convert_action)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        
        info_action = QAction("Image Information", self)
        info_action.setShortcut("Ctrl+I")
        info_action.triggered.connect(self.show_image_info)
        help_menu.addAction(info_action)
        
        help_menu.addSeparator()
        
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def create_toolbar(self):
        toolbar = QToolBar()
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # Open button
        open_btn = QPushButton("📂 Open")
        open_btn.clicked.connect(self.open_image)
        toolbar.addWidget(open_btn)
        
        # Save button
        save_btn = QPushButton("💾 Save")
        save_btn.clicked.connect(self.save_image)
        toolbar.addWidget(save_btn)
        
        # Close button
        close_btn = QPushButton("✖️ Close")
        close_btn.clicked.connect(self.close_image)
        toolbar.addWidget(close_btn)
        
        toolbar.addSeparator()
        
        # Undo button
        undo_btn = QPushButton("↶ Undo")
        undo_btn.clicked.connect(self.undo)
        toolbar.addWidget(undo_btn)
        
        # Redo button
        redo_btn = QPushButton("↷ Redo")
        redo_btn.clicked.connect(self.redo)
        toolbar.addWidget(redo_btn)
        
        toolbar.addSeparator()
        
        # Rotate button
        rotate_btn = QPushButton("↻ Rotate")
        rotate_btn.clicked.connect(lambda: self.rotate_image(90))
        toolbar.addWidget(rotate_btn)
        
        # Flip button  
        flip_btn = QPushButton("⇄ Flip H")
        flip_btn.clicked.connect(lambda: self.flip_image('horizontal'))
        toolbar.addWidget(flip_btn)
        
        toolbar.addSeparator()
        
        # Resize button
        resize_btn = QPushButton("📐 Resize")
        resize_btn.clicked.connect(self.resize_image)
        toolbar.addWidget(resize_btn)
        
        # Crop button
        crop_btn = QPushButton("✂️ Crop")
        crop_btn.clicked.connect(self.crop_image)
        toolbar.addWidget(crop_btn)
        
        toolbar.addSeparator()
        
        # DPI button
        dpi_btn = QPushButton("🔍 DPI")
        dpi_btn.clicked.connect(self.change_dpi)
        toolbar.addWidget(dpi_btn)
        
        # Convert button
        convert_btn = QPushButton("🔄 Convert")
        convert_btn.clicked.connect(self.convert_format)
        toolbar.addWidget(convert_btn)
        
        toolbar.addSeparator()
        
        # Info button
        info_btn = QPushButton("ℹ️ Info")
        info_btn.clicked.connect(self.show_image_info)
        toolbar.addWidget(info_btn)
        
    def save_to_history(self):
        """Save current image state to undo history"""
        if self.current_image:
            # Add current image to undo stack
            self.undo_stack.append(self.current_image.copy())
            
            # Limit history size
            if len(self.undo_stack) > self.max_history:
                self.undo_stack.pop(0)
            
            # Clear redo stack when new action is performed
            self.redo_stack.clear()
            
            # Mark as having unsaved changes
            self.has_unsaved_changes = True
            
    def undo(self):
        """Undo the last operation"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        if not self.undo_stack:
            self.status_bar.showMessage("Nothing to undo", 3000)
            return
        
        # Save current state to redo stack
        self.redo_stack.append(self.current_image.copy())
        
        # Restore previous state
        self.current_image = self.undo_stack.pop()
        
        # Update display
        self.update_display_from_current_image()
        self.status_bar.showMessage("Undo", 2000)
        
    def redo(self):
        """Redo the last undone operation"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        if not self.redo_stack:
            self.status_bar.showMessage("Nothing to redo", 3000)
            return
        
        # Save current state to undo stack
        self.undo_stack.append(self.current_image.copy())
        
        # Restore redo state
        self.current_image = self.redo_stack.pop()
        
        # Update display
        self.update_display_from_current_image()
        self.status_bar.showMessage("Redo", 2000)
        
    def rotate_image(self, degrees):
        """Rotate the current image by specified degrees"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
        
        # Save to history
        self.save_to_history()
        
        try:
            # Rotate: PIL's transpose handles 90/180/270 efficiently
            if degrees == 90:
                self.current_image = self.current_image.transpose(Image.Transpose.ROTATE_270)
            elif degrees == -90:
                self.current_image = self.current_image.transpose(Image.Transpose.ROTATE_90)
            elif degrees == 180:
                self.current_image = self.current_image.transpose(Image.Transpose.ROTATE_180)
            else:
                # Use rotate for arbitrary angles
                self.current_image = self.current_image.rotate(-degrees, expand=True)
            
            # Update display
            self.update_display_from_current_image()
            self.status_bar.showMessage(f"Rotated {degrees}°", 3000)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to rotate image:\n{str(e)}")
            
    def flip_image(self, direction):
        """Flip the current image horizontally or vertically"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
        
        # Save to history
        self.save_to_history()
        
        try:
            if direction == 'horizontal':
                self.current_image = self.current_image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                self.status_bar.showMessage("Flipped horizontally", 3000)
            elif direction == 'vertical':
                self.current_image = self.current_image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                self.status_bar.showMessage("Flipped vertically", 3000)
            
            # Update display
            self.update_display_from_current_image()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to flip image:\n{str(e)}")
            
    def update_display_from_current_image(self):
        """Update the display pixmap from the current PIL image"""
        if not self.current_image:
            return
            
        try:
            # Convert to display format
            display_image = self.current_image
            if display_image.mode == 'RGBA':
                background = Image.new('RGB', display_image.size, (255, 255, 255))
                background.paste(display_image, mask=display_image.split()[3])
                display_image = background
            elif display_image.mode not in ['RGB', 'L']:
                display_image = display_image.convert('RGB')
                
            data = display_image.tobytes('raw', 'RGB')
            qimage = QImage(data, display_image.width, display_image.height,
                          display_image.width * 3, QImage.Format.Format_RGB888)
            self.current_pixmap = QPixmap.fromImage(qimage)
            
            self.update_image_display()
            self.update_status()
            
        except Exception as e:
            print(f"Display update error: {e}")
        
    def close_image(self):
        """Close the current image"""
        if self.current_image:
            # Only warn if there are unsaved changes
            if self.has_unsaved_changes:
                reply = QMessageBox.question(
                    self,
                    "Close Image",
                    "Close the current image? Any unsaved changes will be lost.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply != QMessageBox.StandardButton.Yes:
                    return
            
            self.current_image = None
            self.current_file_path = None
            self.current_pixmap = None
            self.image_label.clear()
            self.image_label.setText("No image loaded")
            self.image_label.setStyleSheet("QLabel { color: #888888; font-size: 16px; }")
            self.setWindowTitle(f"{APP_NAME} - {ORG_NAME}")
            self.status_bar.showMessage("Ready")
            self.has_unsaved_changes = False
            
            # Clear history
            self.undo_stack.clear()
            self.redo_stack.clear()
        
    def open_image(self):
        """Open an image file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Image",
            str(self.last_directory),
            "Image Files (*.png *.jpg *.jpeg *.gif *.bmp *.tiff *.tif *.ico *.icns *.webp);;All Files (*.*)"
        )
        
        if file_path:
            try:
                self.current_file_path = Path(file_path)
                self.last_directory = self.current_file_path.parent  # Remember directory
                
                # Try to open the image
                try:
                    self.current_image = Image.open(file_path)
                    
                    # Special handling for ICO - try to get the largest size
                    if file_path.lower().endswith('.ico'):
                        try:
                            # ICO files contain multiple sizes - get all of them
                            ico_sizes = []
                            temp_img = Image.open(file_path)
                            
                            frame = 0
                            while True:
                                try:
                                    temp_img.seek(frame)
                                    size = temp_img.size
                                    img_copy = temp_img.copy()
                                    ico_sizes.append((size[0] * size[1], size, img_copy))
                                    print(f"Found ICO size: {size}")
                                    frame += 1
                                except EOFError:
                                    break
                                except Exception as e:
                                    break
                            
                            # Use the largest size found
                            if ico_sizes:
                                ico_sizes.sort(reverse=True)
                                largest = ico_sizes[0]
                                self.current_image = largest[2]
                                print(f"Loaded ICO - using largest size: {largest[1]}")
                                self.status_bar.showMessage(
                                    f"Loaded ICO - found {len(ico_sizes)} sizes, using largest: {largest[1][0]}x{largest[1][1]}", 
                                    5000
                                )
                            else:
                                print(f"ICO loading - no additional sizes found, using default: {self.current_image.size}")
                                self.status_bar.showMessage(
                                    f"ICO loaded at {self.current_image.size[0]}x{self.current_image.size[1]} (no multi-size data found)",
                                    5000
                                )
                                
                        except Exception as ico_error:
                            print(f"ICO multi-size loading failed: {ico_error}")
                            print(f"Using default ICO size: {self.current_image.size}")
                    
                    # For ICNS, try to find a good quality frame (not the upscaled 1024x1024)
                    # Pillow's ICNS decoder often reports 1024x1024 but the data is upscaled from smaller sizes
                    if file_path.lower().endswith('.icns'):
                        try:
                            print(f"ICNS initial load: {self.current_image.size}")
                            
                            # Try to find a better frame - look for frames in descending order
                            # Prefer 512x512 or 256x256 which are often the true high-res versions
                            temp_img = Image.open(file_path)
                            found_frames = []
                            
                            for frame_num in range(20):
                                try:
                                    temp_img.seek(frame_num)
                                    frame_size = temp_img.size
                                    img_copy = temp_img.copy()
                                    found_frames.append((frame_num, frame_size, img_copy))
                                    print(f"  Frame {frame_num}: {frame_size}")
                                except EOFError:
                                    break
                                except Exception as e:
                                    break
                            
                            # If we found frames, prefer these sizes in order: 512, 256, 128, then others
                            if found_frames:
                                # Sort by preference: 512 > 256 > 128 > others, but avoid 1024
                                def frame_preference(frame_info):
                                    size = frame_info[1]
                                    w, h = size
                                    # Prefer square images
                                    if w != h:
                                        return 0
                                    # Avoid 1024 (likely upscaled)
                                    if w == 1024:
                                        return 1
                                    # Prefer 512
                                    if w == 512:
                                        return 1000
                                    # Then 256
                                    if w == 256:
                                        return 900
                                    # Then 128
                                    if w == 128:
                                        return 800
                                    # Other sizes
                                    return w
                                
                                found_frames.sort(key=frame_preference, reverse=True)
                                best_frame = found_frames[0]
                                self.current_image = best_frame[2]
                                
                                print(f"Selected ICNS frame {best_frame[0]} at {best_frame[1]}")
                                display_note = " (display capped at 512px)" if best_frame[1][0] > 512 or best_frame[1][1] > 512 else ""
                                self.status_bar.showMessage(
                                    f"Loaded ICNS - selected {best_frame[1][0]}x{best_frame[1][1]} from {len(found_frames)} frames{display_note}",
                                    5000
                                )
                            else:
                                print(f"Loaded ICNS at default size: {self.current_image.size}")
                                self.status_bar.showMessage(
                                    f"Loaded ICNS at {self.current_image.size[0]}x{self.current_image.size[1]} (Pillow default)",
                                    5000
                                )
                        except Exception as icns_error:
                            print(f"ICNS frame selection failed: {icns_error}, using default")
                            self.status_bar.showMessage(
                                f"Loaded ICNS at {self.current_image.size[0]}x{self.current_image.size[1]} (default)",
                                5000
                            )
                            
                except Exception as img_error:
                    # Special handling for ICNS files
                    if file_path.lower().endswith('.icns'):
                        QMessageBox.warning(
                            self, 
                            "ICNS Format Error", 
                            f"Error opening ICNS file: {str(img_error)}\n\n"
                            "ICNS support is built into Pillow but may have limitations.\n"
                            "Try converting the ICNS to PNG first with another tool, or ensure your\n"
                            "Pillow version is up to date: pip install --upgrade Pillow"
                        )
                        return
                    else:
                        raise img_error
                
                # Convert RGBA to RGB if necessary for display
                display_image = self.current_image
                if display_image.mode == 'RGBA':
                    # Create white background
                    background = Image.new('RGB', display_image.size, (255, 255, 255))
                    background.paste(display_image, mask=display_image.split()[3])
                    display_image = background
                elif display_image.mode not in ['RGB', 'L']:
                    display_image = display_image.convert('RGB')
                
                # Convert to QPixmap
                data = display_image.tobytes('raw', 'RGB')
                qimage = QImage(data, display_image.width, display_image.height, 
                              display_image.width * 3, QImage.Format.Format_RGB888)
                self.current_pixmap = QPixmap.fromImage(qimage)
                
                self.has_unsaved_changes = False  # New image, no changes yet
                self.update_image_display()
                self.update_status()
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to open image:\n{str(e)}")
                
    def update_image_display(self):
        """Update the image display"""
        if self.current_pixmap:
            # Calculate available space
            available_size = self.scroll_area.size() * 0.9
            
            # Force icon files to display at 128x128 max (prevents blurry upscaled icons)
            if self.current_file_path and self.current_file_path.suffix.lower() in ['.icns', '.ico']:
                max_icon_display = 128
                scaled_pixmap = self.current_pixmap.scaled(
                    QSize(max_icon_display, max_icon_display),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
                self.image_label.setPixmap(scaled_pixmap)
                self.image_label.resize(scaled_pixmap.size())
            elif (self.current_pixmap.width() > available_size.width() or 
                  self.current_pixmap.height() > available_size.height()):
                # Image is too large - scale it down to fit window
                scaled_pixmap = self.current_pixmap.scaled(
                    available_size,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
                self.image_label.setPixmap(scaled_pixmap)
                self.image_label.resize(scaled_pixmap.size())
            else:
                # Image fits - display at actual size
                self.image_label.setPixmap(self.current_pixmap)
                self.image_label.resize(self.current_pixmap.size())
        else:
            self.image_label.setText("No image loaded")
            
    def update_status(self):
        """Update the status bar with image information"""
        if self.current_image:
            width, height = self.current_image.size
            mode = self.current_image.mode
            format_name = self.current_image.format or "Unknown"
            
            dpi = self.current_image.info.get('dpi', (72, 72))
            if isinstance(dpi, tuple):
                # Handle float DPI values from Pillow
                dpi_str = f"{int(round(dpi[0]))}x{int(round(dpi[1]))}"
            else:
                dpi_str = str(int(round(dpi))) if isinstance(dpi, (int, float)) else str(dpi)
            
            # Update window title with filename
            filename = self.current_file_path.name if self.current_file_path else "Untitled"
            self.setWindowTitle(f"{filename} - {APP_NAME} - {ORG_NAME}")
            
            # Update status bar
            self.status_bar.showMessage(
                f"{filename} | "
                f"{width}x{height} | {mode} | {format_name} | DPI: {dpi_str}"
            )
        else:
            self.setWindowTitle(f"{APP_NAME} - {ORG_NAME}")
            self.status_bar.showMessage("Ready")
            
    def save_image(self):
        """Save the current image"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image to save")
            return
            
        if not self.current_file_path:
            self.save_image_as()
            return
            
        try:
            save_kwargs = {}
            
            # Add DPI info if available
            if 'dpi' in self.current_image.info:
                save_kwargs['dpi'] = self.current_image.info['dpi']
            
            # Add quality for JPEG
            if self.current_file_path.suffix.lower() in ['.jpg', '.jpeg']:
                save_kwargs['quality'] = 95
                
            self.current_image.save(self.current_file_path, **save_kwargs)
            self.has_unsaved_changes = False  # Reset flag after successful save
            self.status_bar.showMessage(f"Saved: {self.current_file_path.name}", 3000)
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save image:\n{str(e)}")
            
    def save_image_as(self):
        """Save the image with a new name/format"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image to save")
            return
        
        # Determine starting directory and filename
        if self.current_file_path:
            default_path = self.current_file_path
        else:
            default_path = self.last_directory / "untitled.png"
            
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Image As",
            str(default_path),
            "PNG (*.png);;JPEG (*.jpg *.jpeg);;GIF (*.gif);;BMP (*.bmp);;"
            "TIFF (*.tiff *.tif);;ICO (*.ico);;ICNS (*.icns);;WebP (*.webp);;All Files (*.*)"
        )
        
        if file_path:
            try:
                self.current_file_path = Path(file_path)
                self.last_directory = self.current_file_path.parent  # Remember directory
                
                save_kwargs = {}
                
                # Add DPI info if available
                if 'dpi' in self.current_image.info:
                    save_kwargs['dpi'] = self.current_image.info['dpi']
                
                # Add quality for JPEG/WebP
                if self.current_file_path.suffix.lower() in ['.jpg', '.jpeg', '.webp']:
                    save_kwargs['quality'] = 95
                
                self.current_image.save(file_path, **save_kwargs)
                self.has_unsaved_changes = False  # Reset flag after successful save
                self.update_status()
                self.status_bar.showMessage(f"Saved: {self.current_file_path.name}", 3000)
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save image:\n{str(e)}")
                
    def resize_image(self):
        """Resize the current image"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        dialog = ResizeDialog(self.current_image.width, self.current_image.height, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_width, new_height = dialog.get_size()
            
            try:
                # Save to history before changing
                self.save_to_history()
                
                # Resize using high-quality resampling
                self.current_image = self.current_image.resize(
                    (new_width, new_height),
                    Image.Resampling.LANCZOS
                )
                
                # Update display
                display_image = self.current_image
                if display_image.mode == 'RGBA':
                    background = Image.new('RGB', display_image.size, (255, 255, 255))
                    background.paste(display_image, mask=display_image.split()[3])
                    display_image = background
                elif display_image.mode not in ['RGB', 'L']:
                    display_image = display_image.convert('RGB')
                    
                data = display_image.tobytes('raw', 'RGB')
                qimage = QImage(data, display_image.width, display_image.height,
                              display_image.width * 3, QImage.Format.Format_RGB888)
                self.current_pixmap = QPixmap.fromImage(qimage)
                
                self.update_image_display()
                self.update_status()
                self.status_bar.showMessage(f"Resized to {new_width}x{new_height}", 3000)
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to resize image:\n{str(e)}")
                
    def crop_image(self):
        """Crop the current image"""
        if not self.current_pixmap:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        dialog = CropDialog(self.current_pixmap, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            crop_rect = dialog.get_crop_rect()
            
            try:
                # Save to history before changing
                self.save_to_history()
                
                # Crop the PIL image
                self.current_image = self.current_image.crop((
                    crop_rect.x(),
                    crop_rect.y(),
                    crop_rect.x() + crop_rect.width(),
                    crop_rect.y() + crop_rect.height()
                ))
                
                # Update display
                display_image = self.current_image
                if display_image.mode == 'RGBA':
                    background = Image.new('RGB', display_image.size, (255, 255, 255))
                    background.paste(display_image, mask=display_image.split()[3])
                    display_image = background
                elif display_image.mode not in ['RGB', 'L']:
                    display_image = display_image.convert('RGB')
                    
                data = display_image.tobytes('raw', 'RGB')
                qimage = QImage(data, display_image.width, display_image.height,
                              display_image.width * 3, QImage.Format.Format_RGB888)
                self.current_pixmap = QPixmap.fromImage(qimage)
                
                self.update_image_display()
                self.update_status()
                self.status_bar.showMessage(
                    f"Cropped to {crop_rect.width()}x{crop_rect.height()}", 3000
                )
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to crop image:\n{str(e)}")
                
    def change_dpi(self):
        """Change the DPI of the current image"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        current_dpi = self.current_image.info.get('dpi', (72, 72))
        image_size = (self.current_image.width, self.current_image.height)
        
        dialog = DPIDialog(current_dpi, image_size, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_dpi = dialog.get_dpi()
            should_resample = dialog.should_resample()
            
            try:
                # Save to history before changing
                self.save_to_history()
                
                if should_resample:
                    # Resample: Change both dimensions AND DPI (like Photoshop with Resample)
                    new_dimensions = dialog.get_new_dimensions()
                    
                    # Show wait cursor for large images
                    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                    self.status_bar.showMessage(f"Resampling to {new_dimensions[0]}×{new_dimensions[1]}...", 0)
                    QApplication.processEvents()  # Update UI to show message
                    
                    try:
                        # Resize the image (this can take time for large images)
                        self.current_image = self.current_image.resize(
                            new_dimensions,
                            Image.Resampling.LANCZOS
                        )
                        
                        # Set the new DPI
                        self.current_image.info['dpi'] = new_dpi
                        
                        # Update display
                        self.update_display_from_current_image()
                        
                        QApplication.restoreOverrideCursor()
                        self.status_bar.showMessage(
                            f"Resampled to {new_dimensions[0]}×{new_dimensions[1]} at {new_dpi[0]}×{new_dpi[1]} DPI", 
                            5000
                        )
                    finally:
                        QApplication.restoreOverrideCursor()
                else:
                    # No resample: Just change DPI metadata (like Photoshop without Resample)
                    self.current_image.info['dpi'] = new_dpi
                    
                    # Mark as changed so it will be saved
                    self.has_unsaved_changes = True
                    
                    self.update_status()
                    self.status_bar.showMessage(
                        f"DPI metadata changed to {new_dpi[0]}×{new_dpi[1]} (save file to persist)", 
                        5000
                    )
                
            except Exception as e:
                QApplication.restoreOverrideCursor()
                QMessageBox.critical(self, "Error", f"Failed to change DPI:\n{str(e)}")
                
    def convert_format(self):
        """Convert the image to a different format"""
        if not self.current_image:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
            
        current_format = self.current_image.format or 'PNG'
        
        dialog = ConvertDialog(current_format, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_format = dialog.get_format()
            quality = dialog.get_quality()
            
            # Get file extension for the format
            extensions = SUPPORTED_FORMATS.get(new_format, ['.png'])
            default_ext = extensions[0]
            
            # Suggest new filename
            if self.current_file_path:
                new_path = self.current_file_path.with_suffix(default_ext)
            else:
                new_path = self.last_directory / f"converted{default_ext}"
            
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                f"Save as {new_format}",
                str(new_path),
                f"{new_format} (*{' *'.join(extensions)});;All Files (*.*)"
            )
            
            if file_path:
                try:
                    save_kwargs = {}
                    
                    # Handle format-specific conversions
                    save_image = self.current_image
                    
                    # Convert RGBA to RGB for formats that don't support transparency
                    if new_format in ['JPEG', 'BMP'] and save_image.mode in ['RGBA', 'LA', 'P']:
                        background = Image.new('RGB', save_image.size, (255, 255, 255))
                        if save_image.mode == 'P':
                            save_image = save_image.convert('RGBA')
                        if save_image.mode in ['RGBA', 'LA']:
                            background.paste(save_image, mask=save_image.split()[-1])
                        else:
                            background.paste(save_image)
                        save_image = background
                    
                    # ICNS format handling - convert to RGBA if needed
                    if new_format == 'ICNS':
                        if save_image.mode not in ['RGBA', 'RGB']:
                            save_image = save_image.convert('RGBA')
                        # ICNS works best at specific sizes (16, 32, 48, 128, 256, 512, 1024)
                        # Warn if size isn't optimal
                        width, height = save_image.size
                        icns_sizes = [16, 32, 48, 128, 256, 512, 1024]
                        if width != height or width not in icns_sizes:
                            reply = QMessageBox.question(
                                self,
                                "ICNS Size Warning",
                                f"Current image size is {width}x{height}.\n\n"
                                f"ICNS files work best with square images at these sizes:\n"
                                f"16x16, 32x32, 48x48, 128x128, 256x256, 512x512, 1024x1024\n\n"
                                f"Pillow's ICNS encoder may have issues with other sizes.\n\n"
                                f"Continue anyway?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No
                            )
                            if reply == QMessageBox.StandardButton.No:
                                return
                    
                    # Add DPI if available and format supports it
                    if 'dpi' in self.current_image.info and new_format not in ['ICNS']:
                        save_kwargs['dpi'] = self.current_image.info['dpi']
                    
                    # Add quality for JPEG/WebP
                    if new_format in ['JPEG', 'WEBP']:
                        save_kwargs['quality'] = quality
                    
                    # Save with new format - special error handling for ICNS
                    try:
                        save_image.save(file_path, format=new_format, **save_kwargs)
                    except Exception as save_error:
                        if new_format == 'ICNS':
                            QMessageBox.critical(
                                self,
                                "ICNS Save Error",
                                f"Failed to save ICNS file: {str(save_error)}\n\n"
                                f"Pillow's ICNS encoder has limitations. Try:\n"
                                f"1. Resize image to a standard ICNS size (256x256, 512x512, or 1024x1024)\n"
                                f"2. Ensure image is square (width = height)\n"
                                f"3. Save as PNG and use a dedicated ICNS converter\n\n"
                                f"Alternative: On macOS, use 'iconutil' or 'sips' command-line tools\n"
                                f"On Windows, use a dedicated icon converter tool"
                            )
                            return
                        else:
                            raise
                    
                    # Update current image, path, and remember directory
                    self.current_image = save_image
                    self.current_file_path = Path(file_path)
                    self.last_directory = self.current_file_path.parent
                    
                    self.update_status()
                    self.status_bar.showMessage(
                        f"Converted to {new_format}: {Path(file_path).name}", 3000
                    )
                    
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to convert image:\n{str(e)}")
                    
    def show_image_info(self):
        """Show detailed image information dialog"""
        if not self.current_image or not self.current_file_path:
            QMessageBox.warning(self, "Warning", "No image loaded")
            return
        
        dialog = ImageInfoDialog(self.current_image, self.current_file_path, self)
        dialog.exec()
                    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self,
            f"About {APP_NAME}",
            f"<h2>{APP_NAME}</h2>"
            f"<p>Version {VERSION}</p>"
            f"<p><b>{ORG_NAME}</b></p>"
            f"<p>A simple image converter and editor</p>"
            f"<p>Features:</p>"
            f"<ul>"
            f"<li>Convert between image formats</li>"
            f"<li>Resize images</li>"
            f"<li>Crop images with interactive handles</li>"
            f"<li>Change DPI</li>"
            f"</ul>"
        )
        
    def apply_dark_theme(self):
        """Apply dark theme to the main window"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e1e;
            }
            QMenuBar {
                background-color: #2b2b2b;
                color: #ffffff;
                border-bottom: 1px solid #3c3c3c;
            }
            QMenuBar::item:selected {
                background-color: #3c3c3c;
            }
            QMenu {
                background-color: #2b2b2b;
                color: #ffffff;
                border: 1px solid #3c3c3c;
            }
            QMenu::item:selected {
                background-color: #3c3c3c;
            }
            QToolBar {
                background-color: #2b2b2b;
                border-bottom: 1px solid #3c3c3c;
                spacing: 5px;
                padding: 5px;
            }
            QPushButton {
                background-color: #3c3c3c;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 5px 10px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #4c4c4c;
            }
            QPushButton:pressed {
                background-color: #2c2c2c;
            }
            QScrollArea {
                background-color: #252525;
                border: none;
            }
            QStatusBar {
                background-color: #2b2b2b;
                color: #ffffff;
                border-top: 1px solid #3c3c3c;
            }
        """)

# =============================================================================
# Main Entry Point
# =============================================================================
def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Create and show splash screen
    splash = create_splash()
    
    if splash:
        splash.show()
        
        # Simulate loading
        for msg in ["Initializing...", "Loading components...", "Almost ready..."]:
            splash.showMessage("\n\n\n\n\n\n\n" + msg,
                             Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                             QColor(255, 255, 255))
            app.processEvents()
            time.sleep(0.3)
    
    # Create main window
    window = ImageOfDeath()
    window.show()
    
    # Finish splash
    if splash:
        splash.finish(window)
    
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
